class RestApiAction{

    bookingId
    bookingUrl = "https://restful-booker.herokuapp.com/booking"
    createBooking(createBodyData) {
        cy.request({
            method: 'POST',
            url: this.bookingUrl,
            body: createBodyData
        }).then((response) => {
            expect(response.status).to.eq(200)
            let bodyData = response.body
            expect(bodyData).to.not.null
            expect(bodyData).has.property('bookingid')
            this.bookingId = bodyData.bookingid
            let actualData = (JSON.stringify(bodyData.booking))
            let expectedData = (JSON.stringify(createBodyData))
            expect(actualData).to.eq(expectedData)
        })
    }

    getAllBookingId(firstName,lastName,checkIn,checkOut) {
        cy.log("Get all booking details by ID")
        cy.request({
            method: 'GET',
            url: this.bookingUrl,
        }).then((response) => {
            expect(response.status).to.eq(200)
            let bodyData = response.body
            expect(bodyData).to.not.null
            expect(bodyData[0]).has.property('bookingid')
        })

        cy.log("Get all booking details by User name")
        cy.request({
            method: 'GET',
            url: this.bookingUrl+"?firstname="+firstName+"&lastname="+lastName+"",
        }).then((response) => {
            expect(response.status).to.eq(200)
            let bodyData = response.body
            expect(bodyData).to.not.null
            expect(bodyData[0]).has.property('bookingid')
        })

        cy.log("Get all booking details by date")
        cy.request({
            method: 'GET',
            url: this.bookingUrl+"?checkin="+checkIn+"&checkout="+checkOut+"",
        }).then((response) => {
            expect(response.status).to.eq(200)
            let bodyData = response.body
            expect(bodyData).to.not.null
            expect(bodyData[0]).has.property('bookingid')
        })
    }

    getBookingDetailsById(firstName,lastName) {
        cy.request({
            method: 'GET',
            url: this.bookingUrl+"/"+this.bookingId,
        }).then((response) => {
            expect(response.status).to.eq(200)
            let bodyData = response.body
            expect(bodyData).to.not.null
            expect(bodyData.firstname).to.eq(firstName)
            expect(bodyData.lastname).to.eq(lastName)
            expect(bodyData).has.property('totalprice')
            expect(bodyData).has.property('depositpaid')
            expect(bodyData).has.property('bookingdates')
            expect(bodyData.bookingdates).has.property('checkin')
            expect(bodyData.bookingdates).has.property('checkout')
        })
    }

    updateBookingDetails(updateBodyData) {
        cy.request({
            method: 'PUT',
            url: this.bookingUrl+"/"+this.bookingId,
            body: updateBodyData
        }).then((response) => {
            expect(response.status).to.eq(200)
            let bodyData = response.body
            expect(bodyData).to.not.null
            expect(bodyData).to.eq(updateBodyData)
        })
    }

    partialUpdateBookingDetails(partialUpdateBodyData) {
        cy.request({
            method: 'PATCH',
            url: this.bookingUrl+"/"+this.bookingId,
            body: partialUpdateBodyData
        }).then((response) => {
            expect(response.status).to.eq(200)
            let bodyData = response.body
            expect(bodyData).to.not.null
            expect(bodyData).to.include(partialUpdateBodyData)
        })
    }

    deleteBookingDetails() {
        cy.request({
            method: 'DELETE',
            url: this.bookingUrl+"/"+this.bookingId,
        }).then((response) => {
            expect(response.status).to.eq(201)
            let bodyData = response.body
            expect(bodyData).to.equal("Created")
        })
    }


}
export default RestApiAction