class HomeAction{

    verifyURL() {
        cy.xpath("//a[@href]").each(page => {
            let link = page.prop('href')
            let pageName = page.text()
            let originsToBlock = ["http://pngimg.com/download/46552", "https://creativecommons.org/licenses/by-nc/4.0/", "https://github.com/inflectra/ui-test-automation-playground",
                "https://www.inflectra.com/Rapise/", "https://www.inflectra.com/", "https://www.apache.org/licenses/LICENSE-2.0"]
            if (originsToBlock.includes(link) === false) {
                cy.request({
                    url: link,
                    failOnStatusCode: true
                })

                cy.visit(link)
                if (pageName === "UITAP" || pageName === "Home") {
                    cy.get("title").then(title => {
                        let txt = title.text()
                        expect(txt).to.have.string("UI Test Automation Playground")
                    })
                } else {
                    cy.get("title").then(title => {
                        let txt = title.text()
                        expect(txt).to.have.string(pageName)
                    })
                }
            }
        })
    }
}
export default HomeAction