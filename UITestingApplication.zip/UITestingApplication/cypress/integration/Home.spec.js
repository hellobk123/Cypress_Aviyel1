import HomeActions from "/cypress/action/HomeAction"

const homeAction = new HomeActions()

describe("UITAP application", () => {
    beforeEach(() => {
        cy.viewport(1280, 720);
        cy.visit("http://uitestingplayground.com/home")
    })

    Cypress.on('uncaught:exception', (err, runnable) => {
        return false
    })

    it.only("Verify URLs are valid and exist with apted title", () => {
        homeAction.verifyURL()
    })
})