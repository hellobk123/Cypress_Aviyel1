import RestActions from "/cypress/action/RestApiAction"

const apiAction = new RestActions();

describe("API testing", () => {

    let createBodyData
    let firstName
    let lastName
    let checkIn
    let checkOut
    let updateBodyData
    let partialUpdateBodyData

    beforeEach(() => {
        cy.viewport(1280, 720);
        cy.fixture("APIData").then((data)=>{
            createBodyData = data.createBodyData;
            firstName = data.createBodyData['firstname']
            lastName= data.createBodyData['lastname']
            checkIn= data.createBodyData['bookingdates']['checkin']
            checkOut= data.createBodyData['bookingdates']['checkout']
            updateBodyData = data.updateBodyData
            partialUpdateBodyData = data.partialUpdateBodyData
        })
    })

    Cypress.on('uncaught:exception', (err, runnable) => {
        return false
    })


    it.only("Create a new booking and verify its created", () => {
        apiAction.createBooking(createBodyData)
    })

    it.only("Get all booking details", () => {
        apiAction.getAllBookingId(firstName,lastName,checkIn,checkOut)
    })

    it.only("Get a particular booking details by id and verify booking details are shown", () => {
        apiAction.getBookingDetailsById()
    })

    it.only("Upadte a particular booking details and verify booking details are updated", () => {
        apiAction.updateBookingDetails(updateBodyData)
    })

    it.only("Upadte a particular booking details with partial details and verify booking details are updated", () => {
        apiAction.partialUpdateBookingDetails(partialUpdateBodyData)
    })

    it.only("Upadte a particular booking details and verify booking details are updated", () => {
        apiAction.updateBookingDetails(partialUpdateBodyData)
    })

    it.only("Delete a particular booking details and verify booking details are deleted", () => {
        apiAction.deleteBookingDetails()
    })

})