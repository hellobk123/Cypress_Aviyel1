1. Extract the zip file
2. Navigate to the workspace and run the command "npm install" to install the package.
3. Run the command to execute the UI Test and API Test.

   npx cypress run --browser chrome --headed --spec "cypress/integration/Home.spec.js"
   npx cypress run --browser chrome --headed --spec "cypress/integration/RestApi.spec.js"



